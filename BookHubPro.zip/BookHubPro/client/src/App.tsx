import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import SearchPage from "@/pages/search-page";
import BookDetailPage from "@/pages/book-detail-page";
import ReadingListPage from "@/pages/reading-list-page";
import WishlistPage from "@/pages/wishlist-page";
import { ProtectedRoute } from "./lib/protected-route";
import { AuthProvider } from "./hooks/use-auth";

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute path="/" component={HomePage} />
      <ProtectedRoute path="/search" component={SearchPage} />
      <ProtectedRoute path="/book/:id" component={BookDetailPage} />
      <ProtectedRoute path="/reading-list" component={ReadingListPage} />
      <ProtectedRoute path="/wishlist" component={WishlistPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router />
      <Toaster />
    </AuthProvider>
  );
}

export default App;
