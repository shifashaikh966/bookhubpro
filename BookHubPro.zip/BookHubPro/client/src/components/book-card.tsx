import { FC } from 'react';
import { useLocation } from 'wouter';
import { Book } from '@shared/schema';
import { StarRating } from '@/components/ui/star-rating';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface BookCardProps {
  book: Book;
  onAddToList?: () => void;
}

export const BookCard: FC<BookCardProps> = ({ book, onAddToList }) => {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const addToWishlistMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', '/api/wishlist', {
        bookId: book.id
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/wishlist'] });
      toast({
        title: 'Added to Wishlist',
        description: `${book.title} has been added to your wishlist.`
      });
    }
  });

  const handleViewDetails = () => {
    navigate(`/book/${book.id}`);
  };

  const handleAddToList = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onAddToList) {
      onAddToList();
    } else {
      addToWishlistMutation.mutate();
    }
  };

  return (
    <Card className="overflow-hidden transition-transform hover:-translate-y-1 hover:shadow-md">
      <div className="relative h-56 overflow-hidden">
        <img 
          src={book.coverImage || 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'} 
          alt={`Cover of ${book.title}`} 
          className="w-full h-full object-cover transition-transform hover:scale-105"
        />
      </div>
      <CardContent className="p-4">
        <h3 className="font-medium text-lg mb-1 line-clamp-1">{book.title}</h3>
        <p className="text-sm text-gray-600 mb-2 line-clamp-1">{book.author}</p>
        <div className="mb-2">
          <StarRating rating={book.rating || 0} />
        </div>
        <div className="flex justify-between mt-2">
          <Button 
            variant="ghost" 
            className="text-primary p-0 h-auto" 
            onClick={handleAddToList}
          >
            <PlusCircle className="h-4 w-4 mr-1" />
            <span className="text-sm">Add to List</span>
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            className="text-sm bg-primary bg-opacity-10 text-primary border-none hover:bg-opacity-20"
            onClick={handleViewDetails}
          >
            Details
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
