import { FC, useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel 
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Genre } from '@shared/schema';

interface BookFilterProps {
  onFilterChange: (filters: BookFilterValues) => void;
  initialValues?: Partial<BookFilterValues>;
}

const bookFilterSchema = z.object({
  genre: z.string().optional(),
  author: z.string().optional(),
  rating: z.string().optional(),
  yearFrom: z.string().optional(),
  yearTo: z.string().optional(),
});

export type BookFilterValues = z.infer<typeof bookFilterSchema>;

export const BookFilter: FC<BookFilterProps> = ({ onFilterChange, initialValues = {} }) => {
  const [mounted, setMounted] = useState(false);
  
  const { data: genres } = useQuery<Genre[]>({
    queryKey: ['/api/genres'],
  });
  
  const form = useForm<BookFilterValues>({
    resolver: zodResolver(bookFilterSchema),
    defaultValues: initialValues,
  });

  // Set form values once initial values or component mounts
  useEffect(() => {
    if (!mounted) {
      setMounted(true);
      if (Object.keys(initialValues).length > 0) {
        form.reset(initialValues);
      }
    }
  }, [form, initialValues, mounted]);

  function onSubmit(values: BookFilterValues) {
    onFilterChange(values);
  }

  return (
    <Card className="mb-10 bg-white shadow-sm">
      <CardContent className="p-4 pt-6">
        <h2 className="text-xl font-semibold mb-4 font-serif">Find Your Perfect Book</h2>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <FormField
                control={form.control}
                name="genre"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-medium text-gray-700">Genre</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="All Genres" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="all">All Genres</SelectItem>
                        {genres?.map((genre) => (
                          <SelectItem key={genre.id} value={genre.name}>
                            {genre.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="author"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-medium text-gray-700">Author</FormLabel>
                    <FormControl>
                      <Input placeholder="Author name" {...field} />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="rating"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-medium text-gray-700">Minimum Rating</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Any Rating" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="any">Any Rating</SelectItem>
                        <SelectItem value="5">★★★★★ (5)</SelectItem>
                        <SelectItem value="4">★★★★☆ (4+)</SelectItem>
                        <SelectItem value="3">★★★☆☆ (3+)</SelectItem>
                        <SelectItem value="2">★★☆☆☆ (2+)</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
              
              <div>
                <FormLabel className="text-sm font-medium text-gray-700">Publication Year</FormLabel>
                <div className="grid grid-cols-2 gap-2">
                  <FormField
                    control={form.control}
                    name="yearFrom"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input type="number" placeholder="From" {...field} />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="yearTo"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input type="number" placeholder="To" {...field} />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              </div>
            </div>
            
            <div className="flex justify-end">
              <Button type="submit" className="bg-primary text-white">
                Apply Filters
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};
