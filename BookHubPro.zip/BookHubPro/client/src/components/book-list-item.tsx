import { FC } from 'react';
import { useLocation } from 'wouter';
import { Book } from '@shared/schema';
import { StarRating } from '@/components/ui/star-rating';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Bookmark, ShoppingCart, Trash2 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface BookListItemProps {
  book: Book;
  progress?: number | null;  // Changed to match ReadingList type
  type: 'reading' | 'wishlist';
  onRemove: () => void;
  onUpdateProgress?: (progress: number) => void;
}

export const BookListItem: FC<BookListItemProps> = ({
  book,
  progress = 0,
  type,
  onRemove,
  onUpdateProgress
}) => {
  const [, navigate] = useLocation();

  const handleClick = () => {
    navigate(`/book/${book.id}`);
  };

  return (
    <div className="flex items-center border-b border-gray-200 pb-4 cursor-pointer" onClick={handleClick}>
      <img 
        src={book.coverImage || 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80'} 
        alt={`Cover of ${book.title}`} 
        className="w-16 h-24 object-cover rounded mr-4"
      />
      <div className="flex-1">
        <h3 className="font-medium text-base">{book.title}</h3>
        <p className="text-sm text-gray-600">{book.author}</p>
        
        {type === 'reading' && (
          <div className="flex items-center text-sm mt-1">
            <span className="mr-2">Progress: {progress}%</span>
            <div className="w-24 h-2 bg-gray-200 rounded-full">
              <Progress value={progress} className="h-2" />
            </div>
          </div>
        )}
        
        {type === 'wishlist' && (
          <div className="mt-1">
            <StarRating rating={book.rating || 0} size="sm" />
          </div>
        )}
      </div>
      
      <div className={cn("flex flex-col gap-2", type === 'wishlist' && "items-end")}>
        <Button 
          variant="ghost" 
          size="icon"
          className="text-primary h-8 w-8"
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
        >
          <Trash2 className="h-5 w-5" />
        </Button>
        
        {type === 'wishlist' && (
          <Button 
            variant="default" 
            size="sm"
            className="bg-primary hover:bg-primary/90 text-white px-3 py-1 rounded text-sm"
            onClick={(e) => {
              e.stopPropagation();
              // Handle add to cart or similar action
            }}
          >
            <ShoppingCart className="h-4 w-4 mr-1" />
            <span>Buy</span>
          </Button>
        )}
      </div>
    </div>
  );
};
