import { FC } from 'react';
import { Link } from 'wouter';
import { BookOpen, Facebook, Twitter, Instagram, Github } from 'lucide-react';

export const Footer: FC = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-serif font-semibold mb-4 flex items-center">
              <BookOpen className="mr-2 h-5 w-5" />
              BookHaven
            </h3>
            <p className="text-sm text-gray-300 mb-6">
              Your personalized journey through the world of books. Discover, track, and share your reading adventures.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-white">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-white">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-white">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-white">
                <Github className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Explore</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/search" className="text-gray-300 hover:text-white">
                  Browse Books
                </Link>
              </li>
              <li>
                <Link href="/search" className="text-gray-300 hover:text-white">
                  Categories
                </Link>
              </li>
              <li>
                <Link href="/search?sort=new" className="text-gray-300 hover:text-white">
                  New Releases
                </Link>
              </li>
              <li>
                <Link href="/search?sort=popular" className="text-gray-300 hover:text-white">
                  Popular Reads
                </Link>
              </li>
              <li>
                <Link href="/authors" className="text-gray-300 hover:text-white">
                  Authors
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Account</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/profile" className="text-gray-300 hover:text-white">
                  Your Profile
                </Link>
              </li>
              <li>
                <Link href="/reading-list" className="text-gray-300 hover:text-white">
                  Reading Lists
                </Link>
              </li>
              <li>
                <Link href="/wishlist" className="text-gray-300 hover:text-white">
                  Wishlist
                </Link>
              </li>
              <li>
                <Link href="/reviews" className="text-gray-300 hover:text-white">
                  Your Reviews
                </Link>
              </li>
              <li>
                <Link href="/settings" className="text-gray-300 hover:text-white">
                  Settings
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Help & Support</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/faq" className="text-gray-300 hover:text-white">
                  FAQ
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-300 hover:text-white">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-gray-300 hover:text-white">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-gray-300 hover:text-white">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-300 hover:text-white">
                  About Us
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-gray-300">© 2023 BookHaven. All rights reserved.</p>
          <div className="mt-4 md:mt-0">
            <Link href="/privacy" className="text-sm text-gray-300 hover:text-white mr-4">
              Privacy Policy
            </Link>
            <Link href="/terms" className="text-sm text-gray-300 hover:text-white mr-4">
              Terms of Service
            </Link>
            <Link href="/cookies" className="text-sm text-gray-300 hover:text-white">
              Cookie Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};
