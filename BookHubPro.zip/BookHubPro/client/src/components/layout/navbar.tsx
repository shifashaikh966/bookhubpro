import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  BookOpen, 
  Search, 
  Bell, 
  User, 
  Menu, 
  Moon, 
  LogOut,
  Heart,
  BookMarked,
  Settings
} from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';

export const Navbar = () => {
  const [location, navigate] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // Navigate to search page with query and use external API
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}&external=true`);
      
      // Reset search input after submitting
      setSearchQuery('');
    }
  };

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex-shrink-0 flex items-center">
              <BookOpen className="text-primary h-6 w-6 mr-2" />
              <span className="font-serif font-bold text-xl text-primary">BookHaven</span>
            </Link>
            <div className="hidden md:ml-6 md:flex md:space-x-8">
              <Link 
                href="/" 
                className={`border-b-2 ${
                  location === '/' 
                    ? 'border-primary text-primary' 
                    : 'border-transparent text-gray-800 hover:text-primary hover:border-primary'
                } px-1 pt-1 font-medium`}
              >
                Home
              </Link>
              <Link 
                href="/search" 
                className={`border-b-2 ${
                  location.includes('/search') 
                    ? 'border-primary text-primary' 
                    : 'border-transparent text-gray-800 hover:text-primary hover:border-primary'
                } px-1 pt-1 font-medium`}
              >
                Browse
              </Link>
              <Link 
                href="/reading-list" 
                className={`border-b-2 ${
                  location.includes('/reading-list') 
                    ? 'border-primary text-primary' 
                    : 'border-transparent text-gray-800 hover:text-primary hover:border-primary'
                } px-1 pt-1 font-medium`}
              >
                Reading Lists
              </Link>
              <Link 
                href="/wishlist" 
                className={`border-b-2 ${
                  location.includes('/wishlist') 
                    ? 'border-primary text-primary' 
                    : 'border-transparent text-gray-800 hover:text-primary hover:border-primary'
                } px-1 pt-1 font-medium`}
              >
                Wishlist
              </Link>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="hidden md:block w-64">
              <form onSubmit={handleSearch} className="relative">
                <Input
                  type="text"
                  placeholder="Search books, authors, genres..."
                  className="w-full py-2 pl-10 pr-4 border border-gray-200 rounded-full text-sm"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-gray-400" />
                </div>
              </form>
            </div>
            <Button variant="ghost" size="icon" className="text-gray-800 hover:text-primary">
              <Moon className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="text-gray-800 hover:text-primary">
              <Bell className="h-5 w-5" />
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage 
                      src="https://images.unsplash.com/photo-1519345182560-3f2917c472ef?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                      alt={user?.username || "User"} 
                    />
                    <AvatarFallback>{user?.username?.charAt(0).toUpperCase() || "U"}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuItem className="font-medium">{user?.username}</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/profile" className="flex items-center cursor-pointer">
                    <User className="mr-2 h-4 w-4" />
                    <span>Profile</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/reading-list" className="flex items-center cursor-pointer">
                    <BookMarked className="mr-2 h-4 w-4" />
                    <span>Reading List</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/wishlist" className="flex items-center cursor-pointer">
                    <Heart className="mr-2 h-4 w-4" />
                    <span>Wishlist</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/settings" className="flex items-center cursor-pointer">
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Settings</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="cursor-pointer">
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            <div className="md:hidden">
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-gray-800 hover:text-primary"
                onClick={toggleMobileMenu}
              >
                <Menu className="h-6 w-6" />
              </Button>
            </div>
          </div>
        </div>
        
        {/* Mobile menu */}
        <div className={`${mobileMenuOpen ? 'block' : 'hidden'} md:hidden`}>
          <div className="pt-2 pb-3 space-y-1">
            <Link
              href="/"
              className={`block pl-3 pr-4 py-2 text-base font-medium ${
                location === '/'
                  ? 'text-primary border-l-4 border-primary'
                  : 'text-gray-800 hover:text-primary border-l-4 border-transparent hover:border-primary'
              }`}
              onClick={() => setMobileMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              href="/search"
              className={`block pl-3 pr-4 py-2 text-base font-medium ${
                location.includes('/search')
                  ? 'text-primary border-l-4 border-primary'
                  : 'text-gray-800 hover:text-primary border-l-4 border-transparent hover:border-primary'
              }`}
              onClick={() => setMobileMenuOpen(false)}
            >
              Browse
            </Link>
            <Link
              href="/reading-list"
              className={`block pl-3 pr-4 py-2 text-base font-medium ${
                location.includes('/reading-list')
                  ? 'text-primary border-l-4 border-primary'
                  : 'text-gray-800 hover:text-primary border-l-4 border-transparent hover:border-primary'
              }`}
              onClick={() => setMobileMenuOpen(false)}
            >
              Reading Lists
            </Link>
            <Link
              href="/wishlist"
              className={`block pl-3 pr-4 py-2 text-base font-medium ${
                location.includes('/wishlist')
                  ? 'text-primary border-l-4 border-primary'
                  : 'text-gray-800 hover:text-primary border-l-4 border-transparent hover:border-primary'
              }`}
              onClick={() => setMobileMenuOpen(false)}
            >
              Wishlist
            </Link>
            <div className="pt-2">
              <form 
                onSubmit={(e) => {
                  handleSearch(e);
                  setMobileMenuOpen(false);
                }}
                className="relative"
              >
                <Input
                  type="text"
                  placeholder="Search..."
                  className="w-full py-2 pl-10 pr-4 border border-gray-200 rounded-full text-sm"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-gray-400" />
                </div>
              </form>
            </div>
          </div>
        </div>
      </nav>
    </header>
  );
};
