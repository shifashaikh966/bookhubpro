import { FC } from 'react';
import { StarRating } from '@/components/ui/star-rating';
import { Card, CardContent } from '@/components/ui/card';
import { ThumbsUp, MessageCircle, Edit } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';

interface ReviewCardProps {
  review: {
    id: number;
    bookId: number;
    bookTitle: string;
    bookCover: string;
    rating: number;
    review: string;
    createdAt: Date;
    likes: number;
    comments: number;
  };
  onEditReview?: () => void;
  variant?: 'compact' | 'full';
  className?: string;
}

export const ReviewCard: FC<ReviewCardProps> = ({
  review,
  onEditReview,
  variant = 'full',
  className
}) => {
  const formattedDate = formatDistanceToNow(new Date(review.createdAt), { addSuffix: true });

  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardContent className={cn("p-6", variant === 'compact' && "p-4")}>
        {variant === 'full' && (
          <div className="flex mb-4">
            <img 
              src={review.bookCover} 
              alt={`Cover of ${review.bookTitle}`} 
              className="w-20 h-28 object-cover rounded-md mr-4"
            />
            <div>
              <h3 className="font-medium text-lg">{review.bookTitle}</h3>
              <StarRating rating={review.rating} className="mb-2" />
              <p className="text-xs text-gray-500">Reviewed {formattedDate}</p>
            </div>
          </div>
        )}
        
        {variant === 'compact' && (
          <div className="flex justify-between items-center mb-3">
            <div>
              <h3 className="font-medium">{review.bookTitle}</h3>
              <StarRating rating={review.rating} size="sm" className="my-1" />
            </div>
            <p className="text-xs text-gray-500">{formattedDate}</p>
          </div>
        )}
        
        <p className={cn(
          "text-sm mb-3",
          variant === 'compact' ? "line-clamp-2" : "mb-4"
        )}>
          {review.review}
        </p>
        
        <div className="flex justify-between items-center">
          <div className="flex items-center text-sm text-gray-600">
            <Button variant="ghost" size="sm" className="h-auto p-1">
              <ThumbsUp className="h-4 w-4 mr-1" />
              <span>{review.likes}</span>
            </Button>
            <Button variant="ghost" size="sm" className="h-auto p-1 ml-2">
              <MessageCircle className="h-4 w-4 mr-1" />
              <span>{review.comments} comments</span>
            </Button>
          </div>
          
          {onEditReview && (
            <Button 
              variant="link" 
              size="sm" 
              className="text-primary p-0 h-auto text-sm"
              onClick={onEditReview}
            >
              <Edit className="h-3 w-3 mr-1" />
              Edit Review
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
