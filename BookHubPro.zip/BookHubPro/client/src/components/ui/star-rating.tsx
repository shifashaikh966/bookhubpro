import { FC } from 'react';
import { Star, StarHalf } from 'lucide-react';
import { cn } from '@/lib/utils';

interface StarRatingProps {
  rating: number;
  showText?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const StarRating: FC<StarRatingProps> = ({ 
  rating, 
  showText = true, 
  size = 'md',
  className
}) => {
  // Calculate full stars and whether there's a half star
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 >= 0.5;
  
  // Determine sizing classes
  const sizeClasses = {
    sm: 'w-3 h-3',
    md: 'w-4 h-4',
    lg: 'w-5 h-5',
  };
  
  const textSizeClasses = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base',
  };
  
  const starSize = sizeClasses[size];
  const textSize = textSizeClasses[size];

  return (
    <div className={cn('flex items-center', className)}>
      <div className="flex">
        {[...Array(5)].map((_, i) => (
          <span key={i} className="text-yellow-400">
            {i < fullStars ? (
              <Star className={cn('fill-current', starSize)} />
            ) : i === fullStars && hasHalfStar ? (
              <StarHalf className={cn('fill-current', starSize)} />
            ) : (
              <Star className={cn('text-gray-300', starSize)} />
            )}
          </span>
        ))}
      </div>
      {showText && (
        <span className={cn('ml-1 text-gray-600', textSize)}>
          {rating.toFixed(1)}
        </span>
      )}
    </div>
  );
};
