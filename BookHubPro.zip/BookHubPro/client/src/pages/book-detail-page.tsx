import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useRoute, useLocation } from 'wouter';
import { Navbar } from '@/components/layout/navbar';
import { Footer } from '@/components/layout/footer';
import { StarRating } from '@/components/ui/star-rating';
import { BookCard } from '@/components/book-card';
import { 
  Book, 
  Review as ReviewType, 
  insertReviewSchema 
} from '@shared/schema';
import { 
  Loader2, 
  BookOpenText, 
  Calendar, 
  Languages, 
  Tag,
  ChevronDown, 
  ChevronUp,
  BookMarked,
  Heart 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { 
  Card, 
  CardContent 
} from '@/components/ui/card';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter,
  DialogClose
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useAuth } from '@/hooks/use-auth';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function BookDetailPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [match, params] = useRoute('/book/:id');
  const bookId = match && params ? parseInt(params.id) : -1;
  
  const [showFullDescription, setShowFullDescription] = useState(false);
  const [reviewDialogOpen, setReviewDialogOpen] = useState(false);

  // Query the book details
  const { 
    data: book, 
    isLoading: isLoadingBook,
    isError: isErrorBook,
    error: bookError
  } = useQuery<Book>({
    queryKey: [`/api/books/${bookId}`],
    enabled: bookId > 0,
  });

  // Query the book reviews
  const {
    data: reviews,
    isLoading: isLoadingReviews
  } = useQuery<ReviewType[]>({
    queryKey: [`/api/books/${bookId}/reviews`],
    enabled: bookId > 0,
  });

  // Query similar books (using the same genre)
  const {
    data: similarBooks,
    isLoading: isLoadingSimilarBooks
  } = useQuery<Book[]>({
    queryKey: [`/api/genres/${book?.genre}/books`],
    enabled: !!book?.genre,
  });

  // Mutations for adding to reading list and wishlist
  const addToReadingListMutation = useMutation({
    mutationFn: async () => {
      if (!user) {
        throw new Error("You must be logged in to add to reading list");
      }
      
      await apiRequest('POST', '/api/reading-list', {
        bookId: bookId,
        progress: 0
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/reading-list'] });
      toast({
        title: 'Added to Reading List',
        description: `${book?.title} has been added to your reading list.`
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: `Failed to add to reading list: ${error.message}`,
        variant: 'destructive'
      });
    }
  });

  const addToWishlistMutation = useMutation({
    mutationFn: async () => {
      if (!user) {
        throw new Error("You must be logged in to add to wishlist");
      }
      
      await apiRequest('POST', '/api/wishlist', {
        bookId: bookId
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/wishlist'] });
      toast({
        title: 'Added to Wishlist',
        description: `${book?.title} has been added to your wishlist.`
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: `Failed to add to wishlist: ${error.message}`,
        variant: 'destructive'
      });
    }
  });

  // Review form schema
  const reviewFormSchema = z.object({
    rating: z.string().min(1, "Please select a rating"),
    review: z.string().min(10, "Review must be at least 10 characters").max(1000, "Review cannot exceed 1000 characters")
  });

  type ReviewFormValues = z.infer<typeof reviewFormSchema>;

  const reviewForm = useForm<ReviewFormValues>({
    resolver: zodResolver(reviewFormSchema),
    defaultValues: {
      rating: "",
      review: ""
    }
  });

  // Submit review mutation
  const submitReviewMutation = useMutation({
    mutationFn: async (values: ReviewFormValues) => {
      if (!user) {
        throw new Error("You must be logged in to submit a review");
      }
      
      const reviewData = insertReviewSchema.parse({
        bookId: bookId,
        userId: user.id,
        rating: parseInt(values.rating),
        review: values.review
      });
      
      await apiRequest('POST', '/api/reviews', reviewData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/books/${bookId}/reviews`] });
      queryClient.invalidateQueries({ queryKey: [`/api/books/${bookId}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/user/reviews'] });
      toast({
        title: 'Review Submitted',
        description: 'Thank you for sharing your thoughts on this book!'
      });
      setReviewDialogOpen(false);
      reviewForm.reset();
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: `Failed to submit review: ${error.message}`,
        variant: 'destructive'
      });
    }
  });

  function onReviewSubmit(values: ReviewFormValues) {
    submitReviewMutation.mutate(values);
  }

  if (isLoadingBook) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="flex items-center justify-center min-h-[80vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-2">Loading book details...</span>
        </div>
      </div>
    );
  }

  if (isErrorBook || !book) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Book Not Found</h1>
          <p className="text-gray-600 mb-8">
            {bookError instanceof Error ? bookError.message : "We couldn't find the book you're looking for."}
          </p>
          <Button onClick={() => navigate('/search')}>Browse Books</Button>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      
      <main className="flex-grow">
        <div className="relative">
          <div className="h-64 bg-gradient-to-r from-primary to-indigo-700 rounded-b-lg" />
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 -mt-32">
          <div className="bg-white rounded-lg shadow-lg p-8">
            <div className="flex flex-col md:flex-row">
              <img 
                src={book.coverImage || 'https://images.unsplash.com/photo-1589998059171-988d887df646?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'} 
                alt={`Cover of ${book.title}`} 
                className="w-40 h-56 object-cover rounded-lg shadow-lg mx-auto md:mx-0"
              />
              
              <div className="md:ml-6 mt-6 md:mt-0">
                <div className="mb-4">
                  <h1 className="text-2xl font-bold font-serif">{book.title}</h1>
                  <p className="text-gray-600">by <span className="text-primary hover:underline cursor-pointer">{book.author}</span></p>
                </div>
                
                <div className="flex items-center mb-4">
                  <StarRating rating={book.rating || 0} size="lg" />
                  <span className="text-sm ml-2">({book.ratingsCount || 0} ratings)</span>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-6">
                  {book.publishedDate && (
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 text-gray-500 mr-2" />
                      <div>
                        <p className="text-sm text-gray-600">Published</p>
                        <p className="font-medium">{book.publishedDate}</p>
                      </div>
                    </div>
                  )}
                  
                  {book.pages && (
                    <div className="flex items-center">
                      <BookOpenText className="h-4 w-4 text-gray-500 mr-2" />
                      <div>
                        <p className="text-sm text-gray-600">Pages</p>
                        <p className="font-medium">{book.pages}</p>
                      </div>
                    </div>
                  )}
                  
                  {book.genre && (
                    <div className="flex items-center">
                      <Tag className="h-4 w-4 text-gray-500 mr-2" />
                      <div>
                        <p className="text-sm text-gray-600">Genre</p>
                        <p className="font-medium">{book.genre}</p>
                      </div>
                    </div>
                  )}
                  
                  {book.language && (
                    <div className="flex items-center">
                      <Languages className="h-4 w-4 text-gray-500 mr-2" />
                      <div>
                        <p className="text-sm text-gray-600">Language</p>
                        <p className="font-medium">{book.language}</p>
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
                  <Button 
                    className="flex-1" 
                    onClick={() => addToReadingListMutation.mutate()}
                    disabled={addToReadingListMutation.isPending}
                  >
                    <BookMarked className="h-4 w-4 mr-2" />
                    Add to Reading List
                  </Button>
                  <Button 
                    variant="outline" 
                    className="flex-1 border-primary text-primary" 
                    onClick={() => addToWishlistMutation.mutate()}
                    disabled={addToWishlistMutation.isPending}
                  >
                    <Heart className="h-4 w-4 mr-2" />
                    Add to Wishlist
                  </Button>
                </div>
              </div>
            </div>
            
            {book.description && (
              <div className="mt-8">
                <h2 className="text-lg font-semibold mb-2 font-serif">Synopsis</h2>
                <p className="text-gray-600">
                  {showFullDescription 
                    ? book.description 
                    : book.description.length > 300 
                      ? `${book.description.substring(0, 300)}...` 
                      : book.description
                  }
                </p>
                
                {book.description.length > 300 && (
                  <Button 
                    variant="ghost" 
                    className="text-primary mt-2 pl-0"
                    onClick={() => setShowFullDescription(!showFullDescription)}
                  >
                    {showFullDescription 
                      ? <>Read less <ChevronUp className="h-4 w-4 ml-1" /></>
                      : <>Read more <ChevronDown className="h-4 w-4 ml-1" /></>
                    }
                  </Button>
                )}
              </div>
            )}
            
            <Separator className="my-8" />
            
            <div>
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold font-serif">Reviews</h2>
                <Button variant="outline" onClick={() => setReviewDialogOpen(true)}>
                  Write a Review
                </Button>
              </div>
              
              {isLoadingReviews ? (
                <div className="flex items-center justify-center py-10">
                  <Loader2 className="h-6 w-6 animate-spin text-primary mr-2" />
                  <span>Loading reviews...</span>
                </div>
              ) : reviews && reviews.length > 0 ? (
                <div className="space-y-4">
                  {reviews.slice(0, 3).map((review) => (
                    <Card key={review.id} className="overflow-hidden">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start mb-2">
                          <div className="flex items-center">
                            <div className="bg-primary text-white rounded-full w-8 h-8 flex items-center justify-center mr-3">
                              <span>U</span>
                            </div>
                            <div>
                              <p className="font-medium">User {review.userId}</p>
                              <StarRating rating={review.rating} size="sm" />
                            </div>
                          </div>
                          <p className="text-xs text-gray-500">
                            {new Date(review.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <p className="text-sm">{review.review}</p>
                      </CardContent>
                    </Card>
                  ))}
                  
                  {reviews.length > 3 && (
                    <div className="text-center mt-4">
                      <Button variant="link" className="text-primary">
                        See all {reviews.length} reviews
                      </Button>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-8 border border-dashed border-gray-300 rounded-lg">
                  <p className="text-gray-500 mb-4">No reviews yet. Be the first to share your thoughts!</p>
                  <Button onClick={() => setReviewDialogOpen(true)}>Write a Review</Button>
                </div>
              )}
            </div>
            
            {isLoadingSimilarBooks ? (
              <div className="flex items-center justify-center py-10 mt-8">
                <Loader2 className="h-6 w-6 animate-spin text-primary mr-2" />
                <span>Finding similar books...</span>
              </div>
            ) : similarBooks && similarBooks.length > 0 ? (
              <div className="mt-8">
                <h2 className="text-lg font-semibold mb-4 font-serif">You May Also Like</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                  {similarBooks.filter(similarBook => similarBook.id !== book.id).slice(0, 5).map((similarBook) => (
                    <BookCard key={similarBook.id} book={similarBook} />
                  ))}
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </main>
      
      <Footer />
      
      {/* Review Dialog */}
      <Dialog open={reviewDialogOpen} onOpenChange={setReviewDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Review "{book.title}"</DialogTitle>
            <DialogDescription>
              Share your thoughts about this book with the community.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...reviewForm}>
            <form onSubmit={reviewForm.handleSubmit(onReviewSubmit)} className="space-y-4">
              <FormField
                control={reviewForm.control}
                name="rating"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Your Rating</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a rating" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="5">★★★★★ (5) Excellent</SelectItem>
                        <SelectItem value="4">★★★★☆ (4) Very Good</SelectItem>
                        <SelectItem value="3">★★★☆☆ (3) Good</SelectItem>
                        <SelectItem value="2">★★☆☆☆ (2) Fair</SelectItem>
                        <SelectItem value="1">★☆☆☆☆ (1) Poor</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={reviewForm.control}
                name="review"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Your Review</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Share your thoughts about this book..." 
                        className="min-h-[100px]"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter className="mt-6">
                <DialogClose asChild>
                  <Button type="button" variant="outline">Cancel</Button>
                </DialogClose>
                <Button 
                  type="submit" 
                  disabled={submitReviewMutation.isPending}
                >
                  {submitReviewMutation.isPending ? 'Submitting...' : 'Submit Review'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
