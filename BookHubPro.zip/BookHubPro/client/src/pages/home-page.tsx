import { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Navbar } from '@/components/layout/navbar';
import { Footer } from '@/components/layout/footer';
import { BookCard } from '@/components/book-card';
import { BookListItem } from '@/components/book-list-item';
import { ReviewCard } from '@/components/review-card';
import { BookFilter, BookFilterValues } from '@/components/book-filter';
import { Book, ReadingList, Wishlist, Review } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { Loader2 } from 'lucide-react';

export default function HomePage() {
  const { user } = useAuth();
  const { toast } = useToast();
  
  console.log("Home page - Current user:", user);

  // Fetch book data
  const { 
    data: recommendations,
    isLoading: isLoadingRecommendations 
  } = useQuery<Book[]>({
    queryKey: ['/api/user/recommendations'],
  });

  const {
    data: scifiBooks,
    isLoading: isLoadingScifiBooks
  } = useQuery<Book[]>({
    queryKey: ['/api/genres/Science Fiction/books'],
  });

  const {
    data: mysteryBooks,
    isLoading: isLoadingMysteryBooks
  } = useQuery<Book[]>({
    queryKey: ['/api/genres/Mystery/books'],
  });

  const {
    data: readingList,
    isLoading: isLoadingReadingList
  } = useQuery<(ReadingList & { book: Book })[]>({
    queryKey: ['/api/user/reading-list'],
  });

  const {
    data: wishlist,
    isLoading: isLoadingWishlist
  } = useQuery<(Wishlist & { book: Book })[]>({
    queryKey: ['/api/user/wishlist'],
  });

  const {
    data: reviews,
    isLoading: isLoadingReviews
  } = useQuery<Review[]>({
    queryKey: ['/api/user/reviews'],
  });

  // Seed initial books if needed
  useEffect(() => {
    // Only run in development to avoid seeding in production
    if (process.env.NODE_ENV !== 'production') {
      const seedBooks = async () => {
        try {
          await apiRequest('POST', '/api/seed');
          console.log('Sample books seeded successfully');
        } catch (error) {
          console.error('Error seeding books:', error);
        }
      };
      
      seedBooks();
    }
  }, []);

  const handleFilterChange = (filters: BookFilterValues) => {
    // Build search URL for redirection or filtering
    const searchParams = new URLSearchParams();
    
    if (filters.genre && filters.genre !== 'all') {
      searchParams.append('genre', filters.genre);
    }
    if (filters.author) {
      searchParams.append('author', filters.author);
    }
    if (filters.rating && filters.rating !== 'any') {
      searchParams.append('rating', filters.rating);
    }
    if (filters.yearFrom) {
      searchParams.append('yearFrom', filters.yearFrom);
    }
    if (filters.yearTo) {
      searchParams.append('yearTo', filters.yearTo);
    }
    
    window.location.href = `/search?${searchParams.toString()}`;
  };

  // Loading states
  const isLoading = 
    isLoadingRecommendations || 
    isLoadingScifiBooks || 
    isLoadingMysteryBooks || 
    isLoadingReadingList || 
    isLoadingWishlist || 
    isLoadingReviews;

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="flex items-center justify-center min-h-[80vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-2">Loading your personalized book haven...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {/* Hero Section */}
          <section className="relative rounded-xl overflow-hidden mb-10 bg-primary bg-opacity-10">
            <div className="max-w-7xl mx-auto">
              <div className="relative z-10 pb-8 sm:pb-16 md:pb-20 lg:max-w-2xl lg:w-full lg:pb-28 xl:pb-32">
                <div className="pt-10 sm:pt-16 lg:pt-8 lg:pb-14 lg:flex">
                  <div className="px-4 lg:px-8 sm:px-6 sm:text-center lg:text-left">
                    <h1 className="text-4xl tracking-tight font-bold text-primary sm:text-5xl md:text-6xl font-serif">
                      <span className="block">Discover Your</span>
                      <span className="block">Next Great Read</span>
                    </h1>
                    <p className="mt-3 text-base text-gray-600 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-0">
                      Access our library of over 130 million books and find your perfect match with personalized recommendations.
                    </p>
                    <div className="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start">
                      <div className="rounded-md shadow">
                        <Link href="/search">
                          <Button className="w-full flex items-center justify-center px-8 py-3 text-base font-medium rounded-md text-white bg-primary hover:bg-opacity-90 md:py-4 md:text-lg md:px-10">
                            Get Started
                          </Button>
                        </Link>
                      </div>
                      <div className="mt-3 sm:mt-0 sm:ml-3">
                        <Link href="/search">
                          <Button variant="outline" className="w-full flex items-center justify-center px-8 py-3 text-base font-medium rounded-md text-primary bg-white hover:bg-gray-50 md:py-4 md:text-lg md:px-10">
                            Browse Books
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="hidden lg:block lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2">
              <img className="h-56 w-full object-cover sm:h-72 md:h-96 lg:w-full lg:h-full" src="https://images.unsplash.com/photo-1507842217343-583bb7270b66?ixlib=rb-1.2.1&auto=format&fit=crop&w=1290&q=80" alt="Books on shelves" />
            </div>
          </section>

          {/* Filter Section */}
          <BookFilter onFilterChange={handleFilterChange} />

          {/* Personalized Recommendations */}
          <section className="mb-10">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold font-serif">Your Recommendations</h2>
              <Link href="/search" className="text-primary hover:underline">See All</Link>
            </div>
            <p className="text-gray-600 mb-4">Based on your reading history and preferences</p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
              {recommendations?.slice(0, 5).map((book) => (
                <BookCard key={book.id} book={book} />
              ))}
              
              {(!recommendations || recommendations.length === 0) && (
                <div className="col-span-full py-8 text-center">
                  <p className="text-gray-500">Start adding books to your reading list to get personalized recommendations!</p>
                </div>
              )}
            </div>
          </section>

          {/* Popular in Your Genres */}
          <section className="mb-10">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold font-serif">Popular in Your Favorite Genres</h2>
              <Link href="/search" className="text-primary hover:underline">See All</Link>
            </div>
            
            {/* Science Fiction */}
            <div className="mb-6">
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-lg font-semibold">Science Fiction</h3>
                <Link href="/search?genre=Science%20Fiction" className="text-sm text-primary hover:underline">Explore Genre</Link>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                {scifiBooks?.slice(0, 5).map((book) => (
                  <BookCard key={book.id} book={book} />
                ))}
              </div>
            </div>
            
            {/* Mystery & Thriller */}
            <div>
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-lg font-semibold">Mystery & Thriller</h3>
                <Link href="/search?genre=Mystery" className="text-sm text-primary hover:underline">Explore Genre</Link>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                {mysteryBooks?.slice(0, 5).map((book) => (
                  <BookCard key={book.id} book={book} />
                ))}
              </div>
            </div>
          </section>

          {/* Reading Lists & Wishlist Section */}
          <section className="mb-10 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold font-serif">Your Reading List</h2>
                <Link href="/reading-list" className="text-primary hover:underline">View All</Link>
              </div>
              
              <div className="space-y-4">
                {readingList?.slice(0, 3).map((item) => (
                  <BookListItem 
                    key={item.id}
                    book={item.book}
                    progress={item.progress}
                    type="reading"
                    onRemove={() => {
                      // Handle remove from reading list
                      apiRequest('DELETE', `/api/reading-list/${item.bookId}`)
                        .then(() => {
                          toast({
                            title: "Removed from Reading List",
                            description: `${item.book.title} has been removed from your reading list.`
                          });
                        })
                        .catch((error) => {
                          toast({
                            title: "Error",
                            description: `Failed to remove book: ${error.message}`,
                            variant: "destructive"
                          });
                        });
                    }}
                  />
                ))}
                
                {(!readingList || readingList.length === 0) && (
                  <div className="py-8 text-center">
                    <p className="text-gray-500">Your reading list is empty. Add books to track your reading progress!</p>
                    <Link href="/search">
                      <Button variant="outline" className="mt-4">
                        Browse Books
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold font-serif">Your Wishlist</h2>
                <Link href="/wishlist" className="text-primary hover:underline">View All</Link>
              </div>
              
              <div className="space-y-4">
                {wishlist?.slice(0, 3).map((item) => (
                  <BookListItem 
                    key={item.id}
                    book={item.book}
                    type="wishlist"
                    onRemove={() => {
                      // Handle remove from wishlist
                      apiRequest('DELETE', `/api/wishlist/${item.bookId}`)
                        .then(() => {
                          toast({
                            title: "Removed from Wishlist",
                            description: `${item.book.title} has been removed from your wishlist.`
                          });
                        })
                        .catch((error) => {
                          toast({
                            title: "Error",
                            description: `Failed to remove book: ${error.message}`,
                            variant: "destructive"
                          });
                        });
                    }}
                  />
                ))}
                
                {(!wishlist || wishlist.length === 0) && (
                  <div className="py-8 text-center">
                    <p className="text-gray-500">Your wishlist is empty. Add books you'd like to read later!</p>
                    <Link href="/search">
                      <Button variant="outline" className="mt-4">
                        Discover Books
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            </div>
          </section>

          {/* Reviews Section */}
          <section className="mb-10">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold font-serif">Your Recent Reviews</h2>
              <Link href="/profile" className="text-primary hover:underline">See All Reviews</Link>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {reviews?.slice(0, 2).map((review) => {
                // Find the book for this review
                const book = [...(recommendations || []), ...(scifiBooks || []), ...(mysteryBooks || [])].find(
                  (b) => b.id === review.bookId
                );
                
                if (!book) return null;
                
                return (
                  <ReviewCard
                    key={review.id}
                    review={{
                      id: review.id,
                      bookId: review.bookId,
                      bookTitle: book.title,
                      bookCover: book.coverImage || '',
                      rating: review.rating,
                      review: review.review || '',
                      createdAt: review.createdAt,
                      likes: 0,
                      comments: 0
                    }}
                    onEditReview={() => {
                      // Handle edit review
                    }}
                  />
                );
              })}
              
              {(!reviews || reviews.length === 0) && (
                <div className="col-span-full py-8 text-center">
                  <p className="text-gray-500">You haven't written any reviews yet. Share your thoughts on the books you've read!</p>
                </div>
              )}
            </div>
          </section>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
