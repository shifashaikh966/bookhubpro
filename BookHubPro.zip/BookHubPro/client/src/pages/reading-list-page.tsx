import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Navbar } from '@/components/layout/navbar';
import { Footer } from '@/components/layout/footer';
import { BookListItem } from '@/components/book-list-item';
import { Button } from '@/components/ui/button';
import { Book, ReadingList } from '@shared/schema';
import { Loader2, BookOpen } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import { Slider } from '@/components/ui/slider';

export default function ReadingListPage() {
  const { toast } = useToast();
  const [updatingItem, setUpdatingItem] = useState<ReadingList & { book: Book } | null>(null);
  const [progress, setProgress] = useState(0);
  
  // Fetch reading list
  const { 
    data: readingList,
    isLoading,
    isError,
    error
  } = useQuery<(ReadingList & { book: Book })[]>({
    queryKey: ['/api/user/reading-list'],
  });

  // Remove from reading list mutation
  const removeFromReadingListMutation = useMutation({
    mutationFn: async (bookId: number) => {
      await apiRequest('DELETE', `/api/reading-list/${bookId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/reading-list'] });
      toast({
        title: 'Removed from Reading List',
        description: 'The book has been removed from your reading list.'
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: `Failed to remove book: ${error.message}`,
        variant: 'destructive'
      });
    }
  });

  // Update reading progress mutation
  const updateProgressMutation = useMutation({
    mutationFn: async ({ id, progress }: { id: number, progress: number }) => {
      await apiRequest('PUT', `/api/reading-list/${id}/progress`, { progress });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/reading-list'] });
      setUpdatingItem(null);
      toast({
        title: 'Progress Updated',
        description: 'Your reading progress has been saved.'
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: `Failed to update progress: ${error.message}`,
        variant: 'destructive'
      });
    }
  });

  const handleUpdateProgress = () => {
    if (updatingItem) {
      updateProgressMutation.mutate({
        id: updatingItem.id,
        progress
      });
    }
  };

  const openProgressDialog = (item: ReadingList & { book: Book }) => {
    setUpdatingItem(item);
    setProgress(item.progress || 0);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="flex items-center justify-center min-h-[80vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-2">Loading your reading list...</span>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Error Loading Reading List</h1>
          <p className="text-gray-600 mb-8">
            {error instanceof Error ? error.message : "We couldn't load your reading list."}
          </p>
          <Button onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/user/reading-list'] })}>
            Try Again
          </Button>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold font-serif">Your Reading List</h1>
              <p className="text-gray-600">Track your reading progress and manage your current reads</p>
            </div>
            <Link href="/search">
              <Button>Browse Books</Button>
            </Link>
          </div>
          
          {readingList && readingList.length > 0 ? (
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="grid grid-cols-1 gap-6">
                {readingList.map((item) => (
                  <BookListItem 
                    key={item.id}
                    book={item.book}
                    progress={item.progress}
                    type="reading"
                    onRemove={() => removeFromReadingListMutation.mutate(item.bookId)}
                    onUpdateProgress={() => openProgressDialog(item)}
                  />
                ))}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-sm p-8 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
                <BookOpen className="h-8 w-8 text-primary" />
              </div>
              <h2 className="text-xl font-bold mb-2">Your reading list is empty</h2>
              <p className="text-gray-600 mb-6 max-w-md mx-auto">
                Books you add to your reading list will appear here. Start exploring and find your next great read!
              </p>
              <Link href="/search">
                <Button>Discover Books</Button>
              </Link>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
      
      {/* Update Progress Dialog */}
      <Dialog open={!!updatingItem} onOpenChange={(open) => !open && setUpdatingItem(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Update Reading Progress</DialogTitle>
          </DialogHeader>
          
          {updatingItem && (
            <div className="py-4">
              <div className="flex items-center mb-6">
                <img 
                  src={updatingItem.book.coverImage || 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80'} 
                  alt={`Cover of ${updatingItem.book.title}`} 
                  className="w-16 h-24 object-cover rounded mr-4"
                />
                <div>
                  <h3 className="font-medium">{updatingItem.book.title}</h3>
                  <p className="text-sm text-gray-600">{updatingItem.book.author}</p>
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">Reading Progress</span>
                    <span className="text-sm text-primary font-medium">{progress}%</span>
                  </div>
                  <Slider
                    value={[progress]}
                    min={0}
                    max={100}
                    step={1}
                    onValueChange={(value) => setProgress(value[0])}
                  />
                </div>
                
                <div className="flex justify-between text-sm text-gray-500">
                  <span>Not Started</span>
                  <span>In Progress</span>
                  <span>Completed</span>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <DialogClose asChild>
              <Button type="button" variant="outline">Cancel</Button>
            </DialogClose>
            <Button 
              onClick={handleUpdateProgress}
              disabled={updateProgressMutation.isPending}
            >
              {updateProgressMutation.isPending ? 'Saving...' : 'Save Progress'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
