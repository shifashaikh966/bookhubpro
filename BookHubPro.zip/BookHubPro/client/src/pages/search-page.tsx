import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Book } from '@shared/schema';
import { Navbar } from '@/components/layout/navbar';
import { Footer } from '@/components/layout/footer';
import { BookCard } from '@/components/book-card';
import { BookFilter, BookFilterValues } from '@/components/book-filter';
import { Button } from '@/components/ui/button';
import { Loader2, Search as SearchIcon } from 'lucide-react';
import { Input } from '@/components/ui/input';

export default function SearchPage() {
  const [location] = useLocation();
  const [searchParams, setSearchParams] = useState(new URLSearchParams(window.location.search));
  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '');
  const [appliedFilters, setAppliedFilters] = useState<BookFilterValues>({
    genre: searchParams.get('genre') || undefined,
    author: searchParams.get('author') || undefined,
    rating: searchParams.get('rating') || undefined,
    yearFrom: searchParams.get('yearFrom') || undefined,
    yearTo: searchParams.get('yearTo') || undefined,
  });

  // Build the query key with search parameters
  const queryParams = new URLSearchParams();
  if (searchQuery) queryParams.append('q', searchQuery);
  if (appliedFilters.genre && appliedFilters.genre !== 'all') queryParams.append('genre', appliedFilters.genre);
  if (appliedFilters.author) queryParams.append('author', appliedFilters.author);
  if (appliedFilters.rating && appliedFilters.rating !== 'any') queryParams.append('rating', appliedFilters.rating);
  if (appliedFilters.yearFrom) queryParams.append('yearFrom', appliedFilters.yearFrom);
  if (appliedFilters.yearTo) queryParams.append('yearTo', appliedFilters.yearTo);
  
  // Use Open Library API for searching the 130,000,000 books
  if (searchQuery) queryParams.append('external', 'true');

  const queryString = queryParams.toString();

  // Fetch books based on search parameters
  // Debug log for query parameters
  console.log("Search query params:", queryParams.toString());
  
  const { 
    data: books, 
    isLoading, 
    isFetching,
    refetch
  } = useQuery<Book[]>({
    queryKey: ['/api/books/search', queryParams.toString()],
    enabled: queryParams.toString().length > 0,
  });

  // Update URL when filters change
  useEffect(() => {
    const newParams = new URLSearchParams();
    if (searchQuery) newParams.append('q', searchQuery);
    if (appliedFilters.genre) newParams.append('genre', appliedFilters.genre);
    if (appliedFilters.author) newParams.append('author', appliedFilters.author);
    if (appliedFilters.rating) newParams.append('rating', appliedFilters.rating);
    if (appliedFilters.yearFrom) newParams.append('yearFrom', appliedFilters.yearFrom);
    if (appliedFilters.yearTo) newParams.append('yearTo', appliedFilters.yearTo);
    
    const newUrl = `/search?${newParams.toString()}`;
    window.history.replaceState({}, '', newUrl);
  }, [searchQuery, appliedFilters]);

  // Update search params from URL when location changes
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setSearchParams(params);
    setSearchQuery(params.get('q') || '');
    setAppliedFilters({
      genre: params.get('genre') || undefined,
      author: params.get('author') || undefined,
      rating: params.get('rating') || undefined,
      yearFrom: params.get('yearFrom') || undefined,
      yearTo: params.get('yearTo') || undefined,
    });
  }, [location]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const newParams = new URLSearchParams();
    if (searchQuery) {
      newParams.append('q', searchQuery);
      // Always use the external API for search to access 130M books
      newParams.append('external', 'true');
    }
    if (appliedFilters.genre && appliedFilters.genre !== 'all') newParams.append('genre', appliedFilters.genre);
    if (appliedFilters.author) newParams.append('author', appliedFilters.author);
    if (appliedFilters.rating && appliedFilters.rating !== 'any') newParams.append('rating', appliedFilters.rating);
    if (appliedFilters.yearFrom) newParams.append('yearFrom', appliedFilters.yearFrom);
    if (appliedFilters.yearTo) newParams.append('yearTo', appliedFilters.yearTo);
    
    const newUrl = `/search?${newParams.toString()}`;
    window.history.pushState({}, '', newUrl);
    
    // Force a new query
    setSearchParams(newParams);
    refetch();
  };

  const handleFilterChange = (filters: BookFilterValues) => {
    setAppliedFilters(filters);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold font-serif mb-2">Book Search</h1>
            <p className="text-gray-600">Explore our vast collection of books and find your next favorite read</p>
          </div>
          
          {/* Mobile Search */}
          <div className="mb-6 md:hidden">
            <form onSubmit={handleSearch} className="flex gap-2">
              <div className="relative flex-grow">
                <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  type="text"
                  placeholder="Search books, authors, genres..."
                  className="pl-10 w-full"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button type="submit">Search</Button>
            </form>
          </div>
          
          {/* Filter Section */}
          <BookFilter 
            onFilterChange={handleFilterChange} 
            initialValues={appliedFilters}
          />
          
          {/* Search Results */}
          <section>
            <div className="flex flex-wrap justify-between items-center mb-6">
              <h2 className="text-2xl font-bold font-serif">
                {searchQuery 
                  ? `Search Results for "${searchQuery}"` 
                  : appliedFilters.genre 
                    ? `Books in ${appliedFilters.genre}` 
                    : "Browse Books"
                }
              </h2>
              
              <div className="text-sm text-gray-600">
                {!isLoading && !isFetching && (
                  <span>{books?.length || 0} book{(books?.length || 0) !== 1 ? 's' : ''} found</span>
                )}
              </div>
            </div>
            
            {(isLoading || isFetching) && (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="h-8 w-8 animate-spin text-primary mr-2" />
                <span>Searching for books...</span>
              </div>
            )}
            
            {!isLoading && !isFetching && books?.length === 0 && (
              <div className="bg-white rounded-lg shadow-sm p-8 text-center">
                <h3 className="text-xl font-medium mb-2">No books found</h3>
                <p className="text-gray-600 mb-6">
                  We couldn't find any books matching your search criteria. Try adjusting your filters or search with different keywords.
                </p>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setSearchQuery('');
                    setAppliedFilters({});
                    window.history.pushState({}, '', '/search');
                    setSearchParams(new URLSearchParams());
                  }}
                >
                  Clear All Filters
                </Button>
              </div>
            )}
            
            {!isLoading && !isFetching && books && books.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                {books.map((book) => (
                  <BookCard key={book.id} book={book} />
                ))}
              </div>
            )}
          </section>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
