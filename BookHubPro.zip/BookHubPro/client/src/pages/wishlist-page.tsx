import { useQuery, useMutation } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Navbar } from '@/components/layout/navbar';
import { Footer } from '@/components/layout/footer';
import { BookListItem } from '@/components/book-list-item';
import { Button } from '@/components/ui/button';
import { Book, Wishlist } from '@shared/schema';
import { Loader2, Heart } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import { useState } from 'react';

export default function WishlistPage() {
  const { toast } = useToast();
  const [confirmItem, setConfirmItem] = useState<Wishlist & { book: Book } | null>(null);
  
  // Fetch wishlist
  const { 
    data: wishlist,
    isLoading,
    isError,
    error
  } = useQuery<(Wishlist & { book: Book })[]>({
    queryKey: ['/api/user/wishlist'],
  });

  // Remove from wishlist mutation
  const removeFromWishlistMutation = useMutation({
    mutationFn: async (bookId: number) => {
      await apiRequest('DELETE', `/api/wishlist/${bookId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/wishlist'] });
      setConfirmItem(null);
      toast({
        title: 'Removed from Wishlist',
        description: 'The book has been removed from your wishlist.'
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: `Failed to remove book: ${error.message}`,
        variant: 'destructive'
      });
    }
  });

  // Add to reading list mutation
  const addToReadingListMutation = useMutation({
    mutationFn: async (bookId: number) => {
      await apiRequest('POST', '/api/reading-list', {
        bookId,
        progress: 0
      });
    },
    onSuccess: (_, bookId) => {
      // Remove from wishlist after adding to reading list
      removeFromWishlistMutation.mutate(bookId);
      
      queryClient.invalidateQueries({ queryKey: ['/api/user/reading-list'] });
      toast({
        title: 'Added to Reading List',
        description: 'The book has been moved from your wishlist to your reading list.'
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: `Failed to add to reading list: ${error.message}`,
        variant: 'destructive'
      });
    }
  });

  const confirmRemove = (item: Wishlist & { book: Book }) => {
    setConfirmItem(item);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="flex items-center justify-center min-h-[80vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-2">Loading your wishlist...</span>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Error Loading Wishlist</h1>
          <p className="text-gray-600 mb-8">
            {error instanceof Error ? error.message : "We couldn't load your wishlist."}
          </p>
          <Button onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/user/wishlist'] })}>
            Try Again
          </Button>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold font-serif">Your Wishlist</h1>
              <p className="text-gray-600">Save books you'd like to read in the future</p>
            </div>
            <Link href="/search">
              <Button>Browse Books</Button>
            </Link>
          </div>
          
          {wishlist && wishlist.length > 0 ? (
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="grid grid-cols-1 gap-6">
                {wishlist.map((item) => (
                  <BookListItem 
                    key={item.id}
                    book={item.book}
                    type="wishlist"
                    onRemove={() => confirmRemove(item)}
                  />
                ))}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-sm p-8 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
                <Heart className="h-8 w-8 text-primary" />
              </div>
              <h2 className="text-xl font-bold mb-2">Your wishlist is empty</h2>
              <p className="text-gray-600 mb-6 max-w-md mx-auto">
                Books you want to read later will appear here. Start exploring and build your wishlist!
              </p>
              <Link href="/search">
                <Button>Discover Books</Button>
              </Link>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
      
      {/* Confirm Remove Dialog */}
      <Dialog open={!!confirmItem} onOpenChange={(open) => !open && setConfirmItem(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Remove from Wishlist</DialogTitle>
            <DialogDescription>
              Do you want to remove this book from your wishlist?
            </DialogDescription>
          </DialogHeader>
          
          {confirmItem && (
            <div className="py-4">
              <div className="flex items-center mb-6">
                <img 
                  src={confirmItem.book.coverImage || 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80'} 
                  alt={`Cover of ${confirmItem.book.title}`} 
                  className="w-16 h-24 object-cover rounded mr-4"
                />
                <div>
                  <h3 className="font-medium">{confirmItem.book.title}</h3>
                  <p className="text-sm text-gray-600">{confirmItem.book.author}</p>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter className="flex flex-col sm:flex-row gap-2">
            <DialogClose asChild>
              <Button type="button" variant="outline" className="sm:flex-1">Cancel</Button>
            </DialogClose>
            <Button 
              variant="outline"
              className="sm:flex-1 border-primary text-primary"
              onClick={() => confirmItem && addToReadingListMutation.mutate(confirmItem.bookId)}
              disabled={addToReadingListMutation.isPending}
            >
              {addToReadingListMutation.isPending ? 'Moving...' : 'Move to Reading List'}
            </Button>
            <Button 
              variant="destructive"
              className="sm:flex-1"
              onClick={() => confirmItem && removeFromWishlistMutation.mutate(confirmItem.bookId)}
              disabled={removeFromWishlistMutation.isPending}
            >
              {removeFromWishlistMutation.isPending ? 'Removing...' : 'Remove'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
