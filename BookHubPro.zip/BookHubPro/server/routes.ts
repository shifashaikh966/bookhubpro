import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { 
  insertBookSchema, insertGenreSchema, insertReviewSchema, 
  insertReadingListSchema, insertWishlistSchema, insertUserPreferenceSchema 
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Book routes
  app.get("/api/books", async (req, res) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
    const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
    const books = await storage.getBooks(limit, offset);
    res.json(books);
  });

  app.get("/api/books/search", async (req, res) => {
    const query = req.query.q as string || "";
    const genre = req.query.genre as string;
    const author = req.query.author as string;
    const minRating = req.query.rating ? parseFloat(req.query.rating as string) : undefined;
    const yearFrom = req.query.yearFrom ? parseInt(req.query.yearFrom as string) : undefined;
    const yearTo = req.query.yearTo ? parseInt(req.query.yearTo as string) : undefined;
    
    // Check if we should try to use Open Library API
    const useOpenLibrary = req.query.external === "true";
    
    if (useOpenLibrary && query) {
      try {
        // Fetch from Open Library API
        const openLibraryUrl = `https://openlibrary.org/search.json?q=${encodeURIComponent(query)}&limit=20`;
        const response = await fetch(openLibraryUrl);
        
        if (!response.ok) {
          throw new Error(`Open Library API responded with status: ${response.status}`);
        }
        
        const data = await response.json();
        
        // Map the Open Library results to our Book format
        const books = data.docs.map((book: any, index: number) => {
          return {
            id: 1000000 + index, // Use high IDs to avoid conflicts with local books
            title: book.title,
            author: book.author_name ? book.author_name[0] : "Unknown Author",
            description: book.description || null,
            coverImage: book.cover_i ? `https://covers.openlibrary.org/b/id/${book.cover_i}-L.jpg` : null,
            publishedDate: book.first_publish_year ? `${book.first_publish_year}-01-01` : null,
            pages: book.number_of_pages_median || null,
            genre: book.subject ? book.subject[0] : null,
            language: book.language ? book.language[0] : null,
            rating: null,
            ratingsCount: null
          };
        });
        
        return res.json(books);
      } catch (error) {
        console.error("Error fetching from Open Library:", error);
        // Fall back to local search if Open Library fails
      }
    }
    
    // If not using Open Library or the API call failed, use local storage
    const filters = {
      genre,
      author,
      minRating,
      yearFrom,
      yearTo
    };
    
    const books = await storage.searchBooks(query, filters);
    res.json(books);
  });

  app.get("/api/books/:id", async (req, res) => {
    const bookId = parseInt(req.params.id);
    
    // Check if this is an Open Library book (IDs start from 1000000)
    if (bookId >= 1000000) {
      try {
        // This is a placeholder as we don't store Open Library books
        // In a real application, we would fetch the book details from Open Library API
        // For now, just return a constructed book based on the ID
        // The actual implementation would use the Open Library Works or Books API
        
        // Example format: https://openlibrary.org/works/OL45804W.json
        const openLibraryWorkId = `OL${(bookId - 1000000) + 45000}W`;
        const response = await fetch(`https://openlibrary.org/works/${openLibraryWorkId}.json`);
        
        if (!response.ok) {
          throw new Error(`Failed to fetch from Open Library: ${response.status}`);
        }
        
        const data = await response.json();
        
        // Extract cover ID if available
        let coverImage = null;
        if (data.covers && data.covers.length > 0) {
          coverImage = `https://covers.openlibrary.org/b/id/${data.covers[0]}-L.jpg`;
        }
        
        // Get author information
        let author = "Unknown Author";
        if (data.authors && data.authors.length > 0) {
          try {
            const authorKey = data.authors[0].author.key;
            const authorResponse = await fetch(`https://openlibrary.org${authorKey}.json`);
            if (authorResponse.ok) {
              const authorData = await authorResponse.json();
              author = authorData.name || "Unknown Author";
            }
          } catch (error) {
            console.error("Error fetching author:", error);
          }
        }
        
        const book = {
          id: bookId,
          title: data.title,
          author: author,
          description: data.description?.value || data.description || null,
          coverImage: coverImage,
          publishedDate: data.first_publish_date || null,
          pages: null,
          genre: data.subjects?.[0] || null,
          language: data.language?.key?.split('/')?.[2] || null,
          rating: null,
          ratingsCount: null
        };
        
        return res.json(book);
      } catch (error) {
        console.error("Error fetching Open Library book:", error);
        return res.status(404).json({ message: "Book not found in Open Library" });
      }
    }
    
    // Regular local book
    const book = await storage.getBook(bookId);
    
    if (!book) {
      return res.status(404).json({ message: "Book not found" });
    }
    
    res.json(book);
  });

  app.post("/api/books", async (req, res) => {
    try {
      const bookData = insertBookSchema.parse(req.body);
      const book = await storage.createBook(bookData);
      res.status(201).json(book);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create book" });
    }
  });

  // Genre routes
  app.get("/api/genres", async (req, res) => {
    const genres = await storage.getGenres();
    res.json(genres);
  });

  app.post("/api/genres", async (req, res) => {
    try {
      const genreData = insertGenreSchema.parse(req.body);
      const genre = await storage.createGenre(genreData);
      res.status(201).json(genre);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create genre" });
    }
  });

  // Books by Genre
  app.get("/api/genres/:genre/books", async (req, res) => {
    const genre = req.params.genre;
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
    const books = await storage.getBooksByGenre(genre, limit);
    res.json(books);
  });

  // Review routes
  app.get("/api/books/:id/reviews", async (req, res) => {
    const bookId = parseInt(req.params.id);
    const reviews = await storage.getReviews(bookId);
    res.json(reviews);
  });

  app.post("/api/reviews", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to post a review" });
    }
    
    try {
      const reviewData = insertReviewSchema.parse({
        ...req.body,
        userId: req.user!.id
      });
      
      const review = await storage.createReview(reviewData);
      res.status(201).json(review);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  app.get("/api/user/reviews", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to view your reviews" });
    }
    
    const reviews = await storage.getUserReviews(req.user!.id);
    res.json(reviews);
  });

  app.put("/api/reviews/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to update a review" });
    }
    
    const reviewId = parseInt(req.params.id);
    
    try {
      const updatedReview = await storage.updateReview(reviewId, req.body);
      
      if (!updatedReview) {
        return res.status(404).json({ message: "Review not found" });
      }
      
      res.json(updatedReview);
    } catch (error) {
      res.status(500).json({ message: "Failed to update review" });
    }
  });

  app.delete("/api/reviews/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to delete a review" });
    }
    
    const reviewId = parseInt(req.params.id);
    const success = await storage.deleteReview(reviewId);
    
    if (!success) {
      return res.status(404).json({ message: "Review not found" });
    }
    
    res.status(204).send();
  });

  // Reading List routes
  app.get("/api/user/reading-list", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to view your reading list" });
    }
    
    const readingList = await storage.getReadingList(req.user!.id);
    
    // Fetch book details for each item in the reading list
    const readingListWithBooks = await Promise.all(
      readingList.map(async (item) => {
        // Check if this is an Open Library book
        if (item.bookId >= 1000000) {
          // Fetch from Open Library using the book/:id endpoint we just created
          const response = await fetch(`http://localhost:${process.env.PORT || 5000}/api/books/${item.bookId}`);
          if (response.ok) {
            const book = await response.json();
            return { ...item, book };
          } else {
            console.error(`Failed to fetch Open Library book with ID ${item.bookId}`);
            return { ...item, book: null };
          }
        } else {
          // Regular local book
          const book = await storage.getBook(item.bookId);
          return { ...item, book };
        }
      })
    );
    
    res.json(readingListWithBooks);
  });

  app.post("/api/reading-list", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to add to your reading list" });
    }
    
    try {
      const readingListData = insertReadingListSchema.parse({
        ...req.body,
        userId: req.user!.id
      });
      
      const item = await storage.addToReadingList(readingListData);
      res.status(201).json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      res.status(500).json({ message: "Failed to add to reading list" });
    }
  });

  app.put("/api/reading-list/:id/progress", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to update progress" });
    }
    
    const itemId = parseInt(req.params.id);
    const { progress } = req.body;
    
    if (typeof progress !== 'number' || progress < 0 || progress > 100) {
      return res.status(400).json({ message: "Progress must be a number between 0 and 100" });
    }
    
    const updatedItem = await storage.updateReadingListProgress(itemId, progress);
    
    if (!updatedItem) {
      return res.status(404).json({ message: "Reading list item not found" });
    }
    
    res.json(updatedItem);
  });

  app.delete("/api/reading-list/:bookId", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to remove from your reading list" });
    }
    
    const bookId = parseInt(req.params.bookId);
    const success = await storage.removeFromReadingList(req.user!.id, bookId);
    
    if (!success) {
      return res.status(404).json({ message: "Book not found in reading list" });
    }
    
    res.status(204).send();
  });

  // Wishlist routes
  app.get("/api/user/wishlist", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to view your wishlist" });
    }
    
    const wishlist = await storage.getWishlist(req.user!.id);
    
    // Fetch book details for each item in the wishlist
    const wishlistWithBooks = await Promise.all(
      wishlist.map(async (item) => {
        // Check if this is an Open Library book
        if (item.bookId >= 1000000) {
          // Fetch from Open Library using the book/:id endpoint we just created
          const response = await fetch(`http://localhost:${process.env.PORT || 5000}/api/books/${item.bookId}`);
          if (response.ok) {
            const book = await response.json();
            return { ...item, book };
          } else {
            console.error(`Failed to fetch Open Library book with ID ${item.bookId}`);
            return { ...item, book: null };
          }
        } else {
          // Regular local book
          const book = await storage.getBook(item.bookId);
          return { ...item, book };
        }
      })
    );
    
    res.json(wishlistWithBooks);
  });

  app.post("/api/wishlist", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to add to your wishlist" });
    }
    
    try {
      const wishlistData = insertWishlistSchema.parse({
        ...req.body,
        userId: req.user!.id
      });
      
      const item = await storage.addToWishlist(wishlistData);
      res.status(201).json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      res.status(500).json({ message: "Failed to add to wishlist" });
    }
  });

  app.delete("/api/wishlist/:bookId", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to remove from your wishlist" });
    }
    
    const bookId = parseInt(req.params.bookId);
    const success = await storage.removeFromWishlist(req.user!.id, bookId);
    
    if (!success) {
      return res.status(404).json({ message: "Book not found in wishlist" });
    }
    
    res.status(204).send();
  });

  // User Preferences routes
  app.get("/api/user/preferences", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to view your preferences" });
    }
    
    const preferences = await storage.getUserPreferences(req.user!.id);
    
    if (!preferences) {
      return res.status(404).json({ message: "Preferences not found" });
    }
    
    res.json(preferences);
  });

  app.put("/api/user/preferences", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to update your preferences" });
    }
    
    try {
      const preferencesData = insertUserPreferenceSchema.parse({
        ...req.body,
        userId: req.user!.id
      });
      
      const preferences = await storage.updateUserPreferences(req.user!.id, preferencesData);
      res.json(preferences);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update preferences" });
    }
  });

  // Recommendations route
  app.get("/api/user/recommendations", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to view recommendations" });
    }
    
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
    const recommendations = await storage.getRecommendedBooks(req.user!.id, limit);
    res.json(recommendations);
  });

  // Seed route to add some initial books (for development purposes)
  app.post("/api/seed", async (req, res) => {
    if (process.env.NODE_ENV === "production") {
      return res.status(403).json({ message: "Seeding not allowed in production" });
    }
    
    // Add some sample books
    const sampleBooks = [
      {
        title: "The Silent Patient",
        author: "Alex Michaelides",
        description: "Alicia Berenson's life is seemingly perfect. A famous painter married to an in-demand fashion photographer, she lives in a grand house with big windows overlooking a park in one of London's most desirable areas. One evening her husband Gabriel returns home late from a fashion shoot, and Alicia shoots him five times in the face, and then never speaks another word.",
        coverImage: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
        publishedDate: "2019-02-05",
        pages: 336,
        genre: "Mystery",
        language: "English",
        rating: 4.5,
        ratingsCount: 325
      },
      {
        title: "The Midnight Library",
        author: "Matt Haig",
        description: "Between life and death there is a library, and within that library, the shelves go on forever. Every book provides a chance to try another life you could have lived. To see how things would be if you had made other choices... Would you have done anything different, if you had the chance to undo your regrets?",
        coverImage: "https://images.unsplash.com/photo-1603163694235-5a8a29db08b8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
        publishedDate: "2020-08-13",
        pages: 304,
        genre: "Fiction",
        language: "English",
        rating: 4.8,
        ratingsCount: 458
      },
      {
        title: "Project Hail Mary",
        author: "Andy Weir",
        description: "Ryland Grace is the sole survivor on a desperate, last-chance mission—and if he fails, humanity and the earth itself will perish. Except that right now, he doesn't know that. He can't even remember his own name, let alone the nature of his assignment or how to complete it.",
        coverImage: "https://images.unsplash.com/photo-1545239351-ef35f43d514b?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
        publishedDate: "2021-05-04",
        pages: 496,
        genre: "Science Fiction",
        language: "English",
        rating: 4.6,
        ratingsCount: 287
      },
      {
        title: "Klara and the Sun",
        author: "Kazuo Ishiguro",
        description: "From her place in the store, Klara, an Artificial Friend with outstanding observational qualities, watches carefully the behavior of those who come in to browse, and of those who pass on the street outside. She remains hopeful that a customer will soon choose her, but when the possibility emerges that her circumstances may change forever, Klara is warned not to invest too much in the promises of humans.",
        coverImage: "https://images.unsplash.com/photo-1633477189729-9290b3261d0a?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
        publishedDate: "2021-03-02",
        pages: 320,
        genre: "Science Fiction",
        language: "English",
        rating: 4.2,
        ratingsCount: 176
      },
      {
        title: "The Four Winds",
        author: "Kristin Hannah",
        description: "Texas, 1934. Millions are out of work and a drought has broken the Great Plains. Farmers are fighting to keep their land and their livelihoods as the crops are failing, the water is drying up, and dust threatens to bury them all. One of the darkest periods of the Great Depression, the Dust Bowl era, has arrived with a vengeance.",
        coverImage: "https://images.unsplash.com/photo-1589998059171-988d887df646?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
        publishedDate: "2021-02-02",
        pages: 464,
        genre: "Historical Fiction",
        language: "English",
        rating: 4.1,
        ratingsCount: 142
      },
      {
        title: "Dune",
        author: "Frank Herbert",
        description: "Set on the desert planet Arrakis, Dune is the story of the boy Paul Atreides, heir to a noble family tasked with ruling an inhospitable world where the only thing of value is the \"spice\" melange, a drug capable of extending life and enhancing consciousness. Coveted across the known universe, melange is a prize worth killing for...",
        coverImage: "https://images.unsplash.com/photo-1518281361980-b26bfd556770?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
        publishedDate: "1965-08-01",
        pages: 412,
        genre: "Science Fiction",
        language: "English",
        rating: 4.7,
        ratingsCount: 876
      },
      {
        title: "The Three-Body Problem",
        author: "Liu Cixin",
        description: "Set against the backdrop of China's Cultural Revolution, a secret military project sends signals into space to establish contact with aliens. An alien civilization on the brink of destruction captures the signal and plans to invade Earth. Meanwhile, on Earth, different camps start forming, planning to either welcome the superior beings and help them take over a world seen as corrupt, or to fight against the invasion.",
        coverImage: "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
        publishedDate: "2014-11-11",
        pages: 400,
        genre: "Science Fiction",
        language: "English",
        rating: 4.3,
        ratingsCount: 312
      },
      {
        title: "Snow Crash",
        author: "Neal Stephenson",
        description: "In reality, Hiro Protagonist delivers pizza for Uncle Enzo's CosaNostra Pizza Inc., but in the Metaverse he's a warrior prince. Plunging headlong into the enigma of a new computer virus that's striking down hackers everywhere, he races along the neon-lit streets on a search-and-destroy mission for the shadowy virtual villain threatening to bring about infocalypse.",
        coverImage: "https://images.unsplash.com/photo-1531989417401-0f85f7e673f8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
        publishedDate: "1992-06-01",
        pages: 480,
        genre: "Science Fiction",
        language: "English",
        rating: 4.2,
        ratingsCount: 298
      },
      {
        title: "The Martian",
        author: "Andy Weir",
        description: "Six days ago, astronaut Mark Watney became one of the first people to walk on Mars. Now, he's sure he'll be the first person to die there. After a dust storm nearly kills him and forces his crew to evacuate while thinking him dead, Mark finds himself stranded and completely alone with no way to even signal Earth that he's alive—and even if he could get word out, his supplies would be gone long before a rescue could arrive.",
        coverImage: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
        publishedDate: "2014-02-11",
        pages: 387,
        genre: "Science Fiction",
        language: "English",
        rating: 4.5,
        ratingsCount: 542
      },
      {
        title: "Gone Girl",
        author: "Gillian Flynn",
        description: "On a warm summer morning in North Carthage, Missouri, it is Nick and Amy Dunne's fifth wedding anniversary. Presents are being wrapped and reservations are being made when Nick's clever and beautiful wife disappears. Husband-of-the-Year Nick isn't doing himself any favors with cringe-worthy daydreams about the slope and shape of his wife's head, but passages from Amy's diary reveal the alpha-girl perfectionist could have put anyone dangerously on edge.",
        coverImage: "https://images.unsplash.com/photo-1587876931567-564ce588bfbd?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80",
        publishedDate: "2012-06-05",
        pages: 432,
        genre: "Mystery",
        language: "English",
        rating: 4.1,
        ratingsCount: 876
      }
    ];
    
    for (const book of sampleBooks) {
      await storage.createBook(book);
    }
    
    res.status(200).json({ message: "Sample books added successfully" });
  });

  const httpServer = createServer(app);

  return httpServer;
}
