import { users, type User, type InsertUser, books, type Book, type InsertBook, 
  genres, type Genre, type InsertGenre, reviews, type Review, type InsertReview,
  readingLists, type ReadingList, type InsertReadingList, wishlists, type Wishlist, 
  type InsertWishlist, userPreferences, type UserPreference, type InsertUserPreference 
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import connectPg from "connect-pg-simple";
import { db, pool } from "./db";
import { and, eq, like, gte, lte, desc, sql, asc } from "drizzle-orm";

const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Book operations
  getBook(id: number): Promise<Book | undefined>;
  getBooks(limit?: number, offset?: number): Promise<Book[]>;
  searchBooks(query: string, filters?: BookFilters): Promise<Book[]>;
  getBooksByGenre(genre: string, limit?: number): Promise<Book[]>;
  createBook(book: InsertBook): Promise<Book>;

  // Genre operations
  getGenres(): Promise<Genre[]>;
  createGenre(genre: InsertGenre): Promise<Genre>;

  // Review operations
  getReviews(bookId: number): Promise<Review[]>;
  getUserReviews(userId: number): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
  updateReview(id: number, review: Partial<InsertReview>): Promise<Review | undefined>;
  deleteReview(id: number): Promise<boolean>;

  // Reading List operations
  getReadingList(userId: number): Promise<ReadingList[]>;
  addToReadingList(item: InsertReadingList): Promise<ReadingList>;
  updateReadingListProgress(id: number, progress: number): Promise<ReadingList | undefined>;
  removeFromReadingList(userId: number, bookId: number): Promise<boolean>;

  // Wishlist operations
  getWishlist(userId: number): Promise<Wishlist[]>;
  addToWishlist(item: InsertWishlist): Promise<Wishlist>;
  removeFromWishlist(userId: number, bookId: number): Promise<boolean>;

  // User Preferences operations
  getUserPreferences(userId: number): Promise<UserPreference | undefined>;
  updateUserPreferences(userId: number, preferences: InsertUserPreference): Promise<UserPreference>;
  
  // Recommendation operations
  getRecommendedBooks(userId: number, limit?: number): Promise<Book[]>;

  // Session store
  sessionStore: any; // Using any to fix type issues with session store
}

export type BookFilters = {
  genre?: string;
  author?: string;
  minRating?: number;
  yearFrom?: number;
  yearTo?: number;
};

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private books: Map<number, Book>;
  private genres: Map<number, Genre>;
  private reviews: Map<number, Review>;
  private readingLists: Map<number, ReadingList>;
  private wishlists: Map<number, Wishlist>;
  private userPreferences: Map<number, UserPreference>;
  
  private userIdCounter: number;
  private bookIdCounter: number;
  private genreIdCounter: number;
  private reviewIdCounter: number;
  private readingListIdCounter: number;
  private wishlistIdCounter: number;
  private userPreferenceIdCounter: number;
  
  sessionStore: any; // Using any for session store type

  constructor() {
    this.users = new Map();
    this.books = new Map();
    this.genres = new Map();
    this.reviews = new Map();
    this.readingLists = new Map();
    this.wishlists = new Map();
    this.userPreferences = new Map();
    
    this.userIdCounter = 1;
    this.bookIdCounter = 1;
    this.genreIdCounter = 1;
    this.reviewIdCounter = 1;
    this.readingListIdCounter = 1;
    this.wishlistIdCounter = 1;
    this.userPreferenceIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
    
    // Initialize with sample genres
    this.initializeGenres();
  }

  // Initialize some sample genres
  private initializeGenres() {
    const sampleGenres = [
      "Fiction", "Non-Fiction", "Science Fiction", "Fantasy", 
      "Mystery", "Romance", "Thriller", "Biography", 
      "History", "Self-Help", "Business", "Poetry"
    ];
    
    sampleGenres.forEach(name => {
      const id = this.genreIdCounter++;
      this.genres.set(id, { id, name });
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const createdAt = new Date();
    const user: User = { ...insertUser, id, createdAt };
    this.users.set(id, user);
    return user;
  }

  // Book operations
  async getBook(id: number): Promise<Book | undefined> {
    return this.books.get(id);
  }

  async getBooks(limit = 20, offset = 0): Promise<Book[]> {
    return Array.from(this.books.values())
      .slice(offset, offset + limit);
  }

  async searchBooks(query: string, filters?: BookFilters): Promise<Book[]> {
    let results = Array.from(this.books.values());
    
    // Apply search query
    if (query) {
      const lowerQuery = query.toLowerCase();
      results = results.filter(book => 
        book.title.toLowerCase().includes(lowerQuery) || 
        book.author.toLowerCase().includes(lowerQuery)
      );
    }
    
    // Apply filters if provided
    if (filters) {
      if (filters.genre) {
        results = results.filter(book => book.genre === filters.genre);
      }
      
      if (filters.author) {
        const lowerAuthor = filters.author.toLowerCase();
        results = results.filter(book => 
          book.author.toLowerCase().includes(lowerAuthor)
        );
      }
      
      if (filters.minRating) {
        results = results.filter(book => 
          book.rating !== null && book.rating >= filters.minRating
        );
      }
      
      if (filters.yearFrom || filters.yearTo) {
        results = results.filter(book => {
          if (!book.publishedDate) return false;
          
          const year = parseInt(book.publishedDate.split('-')[0]);
          
          if (isNaN(year)) return false;
          
          if (filters.yearFrom && year < filters.yearFrom) return false;
          if (filters.yearTo && year > filters.yearTo) return false;
          
          return true;
        });
      }
    }
    
    return results;
  }

  async getBooksByGenre(genre: string, limit = 5): Promise<Book[]> {
    return Array.from(this.books.values())
      .filter(book => book.genre === genre)
      .slice(0, limit);
  }

  async createBook(insertBook: InsertBook): Promise<Book> {
    const id = this.bookIdCounter++;
    const book: Book = { ...insertBook, id };
    this.books.set(id, book);
    return book;
  }

  // Genre operations
  async getGenres(): Promise<Genre[]> {
    return Array.from(this.genres.values());
  }

  async createGenre(insertGenre: InsertGenre): Promise<Genre> {
    const id = this.genreIdCounter++;
    const genre: Genre = { ...insertGenre, id };
    this.genres.set(id, genre);
    return genre;
  }

  // Review operations
  async getReviews(bookId: number): Promise<Review[]> {
    return Array.from(this.reviews.values())
      .filter(review => review.bookId === bookId);
  }

  async getUserReviews(userId: number): Promise<Review[]> {
    return Array.from(this.reviews.values())
      .filter(review => review.userId === userId);
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const id = this.reviewIdCounter++;
    const createdAt = new Date();
    const review: Review = { ...insertReview, id, createdAt };
    this.reviews.set(id, review);
    
    // Update book rating
    const bookReviews = await this.getReviews(insertReview.bookId);
    const book = await this.getBook(insertReview.bookId);
    
    if (book) {
      const totalRating = bookReviews.reduce((sum, review) => sum + review.rating, 0);
      const avgRating = totalRating / bookReviews.length;
      
      this.books.set(insertReview.bookId, {
        ...book,
        rating: parseFloat(avgRating.toFixed(1)),
        ratingsCount: bookReviews.length
      });
    }
    
    return review;
  }

  async updateReview(id: number, reviewUpdate: Partial<InsertReview>): Promise<Review | undefined> {
    const existingReview = this.reviews.get(id);
    
    if (!existingReview) return undefined;
    
    const updatedReview: Review = { ...existingReview, ...reviewUpdate };
    this.reviews.set(id, updatedReview);
    
    // Update book rating if rating changed
    if (reviewUpdate.rating) {
      const bookReviews = await this.getReviews(existingReview.bookId);
      const book = await this.getBook(existingReview.bookId);
      
      if (book) {
        const totalRating = bookReviews.reduce((sum, review) => sum + review.rating, 0);
        const avgRating = totalRating / bookReviews.length;
        
        this.books.set(existingReview.bookId, {
          ...book,
          rating: parseFloat(avgRating.toFixed(1)),
          ratingsCount: bookReviews.length
        });
      }
    }
    
    return updatedReview;
  }

  async deleteReview(id: number): Promise<boolean> {
    const review = this.reviews.get(id);
    
    if (!review) return false;
    
    this.reviews.delete(id);
    
    // Update book rating
    const bookId = review.bookId;
    const bookReviews = await this.getReviews(bookId);
    const book = await this.getBook(bookId);
    
    if (book) {
      if (bookReviews.length === 0) {
        this.books.set(bookId, {
          ...book,
          rating: 0,
          ratingsCount: 0
        });
      } else {
        const totalRating = bookReviews.reduce((sum, review) => sum + review.rating, 0);
        const avgRating = totalRating / bookReviews.length;
        
        this.books.set(bookId, {
          ...book,
          rating: parseFloat(avgRating.toFixed(1)),
          ratingsCount: bookReviews.length
        });
      }
    }
    
    return true;
  }

  // Reading List operations
  async getReadingList(userId: number): Promise<ReadingList[]> {
    return Array.from(this.readingLists.values())
      .filter(item => item.userId === userId);
  }

  async addToReadingList(insertItem: InsertReadingList): Promise<ReadingList> {
    // First check if it already exists
    const existing = Array.from(this.readingLists.values()).find(
      item => item.userId === insertItem.userId && item.bookId === insertItem.bookId
    );
    
    if (existing) {
      return existing;
    }
    
    const id = this.readingListIdCounter++;
    const addedAt = new Date();
    const item: ReadingList = { ...insertItem, id, addedAt };
    this.readingLists.set(id, item);
    return item;
  }

  async updateReadingListProgress(id: number, progress: number): Promise<ReadingList | undefined> {
    const item = this.readingLists.get(id);
    
    if (!item) return undefined;
    
    const updatedItem: ReadingList = { ...item, progress };
    this.readingLists.set(id, updatedItem);
    return updatedItem;
  }

  async removeFromReadingList(userId: number, bookId: number): Promise<boolean> {
    const items = Array.from(this.readingLists.values());
    const itemToRemove = items.find(
      item => item.userId === userId && item.bookId === bookId
    );
    
    if (!itemToRemove) return false;
    
    this.readingLists.delete(itemToRemove.id);
    return true;
  }

  // Wishlist operations
  async getWishlist(userId: number): Promise<Wishlist[]> {
    return Array.from(this.wishlists.values())
      .filter(item => item.userId === userId);
  }

  async addToWishlist(insertItem: InsertWishlist): Promise<Wishlist> {
    // First check if it already exists
    const existing = Array.from(this.wishlists.values()).find(
      item => item.userId === insertItem.userId && item.bookId === insertItem.bookId
    );
    
    if (existing) {
      return existing;
    }
    
    const id = this.wishlistIdCounter++;
    const addedAt = new Date();
    const item: Wishlist = { ...insertItem, id, addedAt };
    this.wishlists.set(id, item);
    return item;
  }

  async removeFromWishlist(userId: number, bookId: number): Promise<boolean> {
    const items = Array.from(this.wishlists.values());
    const itemToRemove = items.find(
      item => item.userId === userId && item.bookId === bookId
    );
    
    if (!itemToRemove) return false;
    
    this.wishlists.delete(itemToRemove.id);
    return true;
  }

  // User Preferences operations
  async getUserPreferences(userId: number): Promise<UserPreference | undefined> {
    return Array.from(this.userPreferences.values())
      .find(pref => pref.userId === userId);
  }

  async updateUserPreferences(userId: number, insertPreferences: InsertUserPreference): Promise<UserPreference> {
    const existing = await this.getUserPreferences(userId);
    
    if (existing) {
      const updatedPreferences: UserPreference = { ...existing, ...insertPreferences };
      this.userPreferences.set(existing.id, updatedPreferences);
      return updatedPreferences;
    } else {
      const id = this.userPreferenceIdCounter++;
      const newPreferences: UserPreference = { ...insertPreferences, id, userId };
      this.userPreferences.set(id, newPreferences);
      return newPreferences;
    }
  }

  // Recommendation operations
  async getRecommendedBooks(userId: number, limit = 5): Promise<Book[]> {
    const userPreferences = await this.getUserPreferences(userId);
    const allBooks = Array.from(this.books.values());
    
    if (!userPreferences || !userPreferences.favoriteGenres?.length) {
      // If no preferences, return popular books based on rating
      return allBooks
        .sort((a, b) => (b.rating || 0) - (a.rating || 0))
        .slice(0, limit);
    }
    
    // Get books matching user's favorite genres
    const recommendedBooks = allBooks
      .filter(book => book.genre && userPreferences.favoriteGenres.includes(book.genre))
      .sort((a, b) => (b.rating || 0) - (a.rating || 0))
      .slice(0, limit);
    
    // If not enough books found, add some popular ones from other genres
    if (recommendedBooks.length < limit) {
      const otherBooks = allBooks
        .filter(book => !recommendedBooks.find(rb => rb.id === book.id))
        .sort((a, b) => (b.rating || 0) - (a.rating || 0))
        .slice(0, limit - recommendedBooks.length);
      
      recommendedBooks.push(...otherBooks);
    }
    
    return recommendedBooks;
  }
}

export class DatabaseStorage implements IStorage {
  sessionStore: any; // Using any for session store type

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
    
    // Initialize the database with sample genres if needed
    this.initializeSampleGenres();
  }

  // Seed the database with sample genres if empty
  private async initializeSampleGenres() {
    const existingGenres = await this.getGenres();
    
    if (existingGenres.length === 0) {
      const sampleGenres = [
        "Fiction", "Non-Fiction", "Science Fiction", "Fantasy", 
        "Mystery", "Romance", "Thriller", "Biography", 
        "History", "Self-Help", "Business", "Poetry"
      ];
      
      for (const name of sampleGenres) {
        await this.createGenre({ name });
      }
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Book operations
  async getBook(id: number): Promise<Book | undefined> {
    const [book] = await db.select().from(books).where(eq(books.id, id));
    return book;
  }

  async getBooks(limit = 20, offset = 0): Promise<Book[]> {
    return await db.select().from(books).limit(limit).offset(offset);
  }

  async searchBooks(query: string, filters?: BookFilters): Promise<Book[]> {
    let conditions = [];
    
    // Apply search query
    if (query) {
      const searchPattern = `%${query}%`;
      conditions.push(
        sql`(${books.title} ILIKE ${searchPattern} OR ${books.author} ILIKE ${searchPattern})`
      );
    }
    
    // Apply filters
    if (filters) {
      if (filters.genre) {
        conditions.push(eq(books.genre, filters.genre));
      }
      
      if (filters.author) {
        conditions.push(like(books.author, `%${filters.author}%`));
      }
      
      if (filters.minRating) {
        conditions.push(gte(books.rating, filters.minRating));
      }
      
      if (filters.yearFrom || filters.yearTo) {
        // Extract year from published date string
        if (filters.yearFrom) {
          conditions.push(
            sql`EXTRACT(YEAR FROM TO_DATE(${books.publishedDate}, 'YYYY-MM-DD')) >= ${filters.yearFrom}`
          );
        }
        
        if (filters.yearTo) {
          conditions.push(
            sql`EXTRACT(YEAR FROM TO_DATE(${books.publishedDate}, 'YYYY-MM-DD')) <= ${filters.yearTo}`
          );
        }
      }
    }
    
    // Build the query based on conditions
    if (conditions.length > 0) {
      return await db.select().from(books).where(and(...conditions));
    } else {
      return await db.select().from(books);
    }
  }

  async getBooksByGenre(genre: string, limit = 5): Promise<Book[]> {
    return await db
      .select()
      .from(books)
      .where(eq(books.genre, genre))
      .limit(limit);
  }

  async createBook(insertBook: InsertBook): Promise<Book> {
    const [book] = await db.insert(books).values(insertBook).returning();
    return book;
  }

  // Genre operations
  async getGenres(): Promise<Genre[]> {
    return await db.select().from(genres);
  }

  async createGenre(insertGenre: InsertGenre): Promise<Genre> {
    const [genre] = await db.insert(genres).values(insertGenre).returning();
    return genre;
  }

  // Review operations
  async getReviews(bookId: number): Promise<Review[]> {
    return await db
      .select()
      .from(reviews)
      .where(eq(reviews.bookId, bookId));
  }

  async getUserReviews(userId: number): Promise<Review[]> {
    return await db
      .select()
      .from(reviews)
      .where(eq(reviews.userId, userId));
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const [review] = await db.insert(reviews).values(insertReview).returning();
    
    // Update book rating
    await this.updateBookRating(insertReview.bookId);
    
    return review;
  }

  async updateReview(id: number, reviewUpdate: Partial<InsertReview>): Promise<Review | undefined> {
    const [existingReview] = await db
      .select()
      .from(reviews)
      .where(eq(reviews.id, id));
    
    if (!existingReview) return undefined;
    
    const [updatedReview] = await db
      .update(reviews)
      .set(reviewUpdate)
      .where(eq(reviews.id, id))
      .returning();
    
    // Update book rating if rating changed
    if (reviewUpdate.rating) {
      await this.updateBookRating(existingReview.bookId);
    }
    
    return updatedReview;
  }

  async deleteReview(id: number): Promise<boolean> {
    const [review] = await db
      .select()
      .from(reviews)
      .where(eq(reviews.id, id));
    
    if (!review) return false;
    
    await db.delete(reviews).where(eq(reviews.id, id));
    
    // Update book rating
    await this.updateBookRating(review.bookId);
    
    return true;
  }

  // Helper method to update book rating based on reviews
  private async updateBookRating(bookId: number): Promise<void> {
    const bookReviews = await this.getReviews(bookId);
    
    if (bookReviews.length === 0) {
      await db
        .update(books)
        .set({ rating: 0, ratingsCount: 0 })
        .where(eq(books.id, bookId));
    } else {
      const totalRating = bookReviews.reduce((sum, review) => sum + review.rating, 0);
      const avgRating = parseFloat((totalRating / bookReviews.length).toFixed(1));
      
      await db
        .update(books)
        .set({ 
          rating: avgRating, 
          ratingsCount: bookReviews.length 
        })
        .where(eq(books.id, bookId));
    }
  }

  // Reading List operations
  async getReadingList(userId: number): Promise<ReadingList[]> {
    return await db
      .select()
      .from(readingLists)
      .where(eq(readingLists.userId, userId));
  }

  async addToReadingList(insertItem: InsertReadingList): Promise<ReadingList> {
    // Check if it already exists
    const [existing] = await db
      .select()
      .from(readingLists)
      .where(
        and(
          eq(readingLists.userId, insertItem.userId),
          eq(readingLists.bookId, insertItem.bookId)
        )
      );
    
    if (existing) {
      return existing;
    }
    
    const [item] = await db.insert(readingLists).values(insertItem).returning();
    return item;
  }

  async updateReadingListProgress(id: number, progress: number): Promise<ReadingList | undefined> {
    const [existing] = await db
      .select()
      .from(readingLists)
      .where(eq(readingLists.id, id));
    
    if (!existing) return undefined;
    
    const [updated] = await db
      .update(readingLists)
      .set({ progress })
      .where(eq(readingLists.id, id))
      .returning();
    
    return updated;
  }

  async removeFromReadingList(userId: number, bookId: number): Promise<boolean> {
    const result = await db
      .delete(readingLists)
      .where(
        and(
          eq(readingLists.userId, userId),
          eq(readingLists.bookId, bookId)
        )
      );
    
    return result.rowCount > 0;
  }

  // Wishlist operations
  async getWishlist(userId: number): Promise<Wishlist[]> {
    return await db
      .select()
      .from(wishlists)
      .where(eq(wishlists.userId, userId));
  }

  async addToWishlist(insertItem: InsertWishlist): Promise<Wishlist> {
    // Check if it already exists
    const [existing] = await db
      .select()
      .from(wishlists)
      .where(
        and(
          eq(wishlists.userId, insertItem.userId),
          eq(wishlists.bookId, insertItem.bookId)
        )
      );
    
    if (existing) {
      return existing;
    }
    
    const [item] = await db.insert(wishlists).values(insertItem).returning();
    return item;
  }

  async removeFromWishlist(userId: number, bookId: number): Promise<boolean> {
    const result = await db
      .delete(wishlists)
      .where(
        and(
          eq(wishlists.userId, userId),
          eq(wishlists.bookId, bookId)
        )
      );
    
    return result.rowCount > 0;
  }

  // User Preferences operations
  async getUserPreferences(userId: number): Promise<UserPreference | undefined> {
    const [preferences] = await db
      .select()
      .from(userPreferences)
      .where(eq(userPreferences.userId, userId));
    
    return preferences;
  }

  async updateUserPreferences(userId: number, preferences: InsertUserPreference): Promise<UserPreference> {
    const [existing] = await db
      .select()
      .from(userPreferences)
      .where(eq(userPreferences.userId, userId));
    
    if (existing) {
      const [updated] = await db
        .update(userPreferences)
        .set(preferences)
        .where(eq(userPreferences.id, existing.id))
        .returning();
      
      return updated;
    } else {
      const [created] = await db
        .insert(userPreferences)
        .values({
          ...preferences,
          userId
        })
        .returning();
      
      return created;
    }
  }
  
  // Recommendation operations
  async getRecommendedBooks(userId: number, limit = 5): Promise<Book[]> {
    const userPrefs = await this.getUserPreferences(userId);
    
    if (!userPrefs || !userPrefs.favoriteGenres?.length) {
      // If no preferences, return popular books based on rating
      return await db
        .select()
        .from(books)
        .orderBy(desc(books.rating))
        .limit(limit);
    }
    
    // Get books that match user's favorite genres
    const genreBooks = await db
      .select()
      .from(books)
      .where(sql`${books.genre} = ANY(${userPrefs.favoriteGenres})`)
      .orderBy(desc(books.rating))
      .limit(limit);
    
    // If not enough books found, add some popular ones
    if (genreBooks.length < limit) {
      const remainingNeeded = limit - genreBooks.length;
      const genreBookIds = genreBooks.map(book => book.id);
      
      const additionalBooks = await db
        .select()
        .from(books)
        .where(sql`${books.id} != ALL(${genreBookIds})`)
        .orderBy(desc(books.rating))
        .limit(remainingNeeded);
      
      return [...genreBooks, ...additionalBooks];
    }
    
    return genreBooks;
  }
}

// Replace MemStorage with DatabaseStorage for production
export const storage = new DatabaseStorage();
